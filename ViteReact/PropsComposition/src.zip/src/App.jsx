import { useState } from 'react';
import Navbar from './Components/Navbar';
import ToDoApp from './Components/ToDoApp';
import Login from './Components/Login';

function App() {
  const [value, setValue] = useState(false);
  const [isDark, setIsDark] = useState(false);

  return (
    <div className={isDark ? "min-h-screen bg-gray-900" : "min-h-screen bg-amber-50"}>
      
      <Navbar 
        value={value} 
        setValue={setValue} 
        isDark={isDark} 
        setIsDark={setIsDark}
      />

      {value ? <ToDoApp isDark={isDark}/> : <Login isDark={isDark}/>}

    </div>
  )
}

export default App;
